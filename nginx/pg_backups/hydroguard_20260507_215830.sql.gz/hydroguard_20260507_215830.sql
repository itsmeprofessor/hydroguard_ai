--
-- PostgreSQL database dump
--

\restrict TeadJImy097ytkW6YA6YOYwPulON9SFxxBbD9UqjTyJU5CfNshxdAyDpcgbISCq

-- Dumped from database version 16.13
-- Dumped by pg_dump version 16.13

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: anomaly_records; Type: TABLE; Schema: public; Owner: hydroguard
--

CREATE TABLE public.anomaly_records (
    id integer NOT NULL,
    city character varying(100),
    region character varying(100),
    date timestamp without time zone,
    tmin double precision,
    tmax double precision,
    tavg double precision,
    prcp double precision,
    wspd double precision,
    humidity double precision,
    pressure double precision,
    dew_point double precision,
    cloud_cover double precision,
    anomaly_score double precision NOT NULL,
    threshold double precision NOT NULL,
    is_anomaly boolean NOT NULL,
    risk_level character varying(20),
    hri_score integer,
    hri_label character varying(20),
    cloudburst_risk_score double precision,
    cloudburst_risk_category character varying(20),
    is_cloudburst_likely boolean,
    remarks text,
    feature_contributions json,
    detailed_explanation json,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    inference_id character varying(36),
    model_version character varying(64)
);


ALTER TABLE public.anomaly_records OWNER TO hydroguard;

--
-- Name: anomaly_records_id_seq; Type: SEQUENCE; Schema: public; Owner: hydroguard
--

CREATE SEQUENCE public.anomaly_records_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.anomaly_records_id_seq OWNER TO hydroguard;

--
-- Name: anomaly_records_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: hydroguard
--

ALTER SEQUENCE public.anomaly_records_id_seq OWNED BY public.anomaly_records.id;


--
-- Name: calibration_state; Type: TABLE; Schema: public; Owner: hydroguard
--

CREATE TABLE public.calibration_state (
    id character varying(36) NOT NULL,
    city_slug character varying(64) NOT NULL,
    model_version character varying(64) NOT NULL,
    calibrated_at timestamp with time zone NOT NULL,
    is_active boolean DEFAULT false NOT NULL,
    n_calibration_samples integer,
    brier_score_before double precision,
    brier_score_after double precision,
    ece_before double precision,
    ece_after double precision,
    artifact_path text NOT NULL,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.calibration_state OWNER TO hydroguard;

--
-- Name: drift_state; Type: TABLE; Schema: public; Owner: hydroguard
--

CREATE TABLE public.drift_state (
    id character varying(36) NOT NULL,
    city_slug character varying(64) NOT NULL,
    checked_at timestamp with time zone NOT NULL,
    window_size integer NOT NULL,
    reference_rows integer NOT NULL,
    psi_scores json NOT NULL,
    max_psi double precision NOT NULL,
    drift_level character varying(16) NOT NULL,
    retrain_triggered boolean DEFAULT false NOT NULL,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.drift_state OWNER TO hydroguard;

--
-- Name: feature_snapshots; Type: TABLE; Schema: public; Owner: hydroguard
--

CREATE TABLE public.feature_snapshots (
    id character varying(36) NOT NULL,
    city_slug character varying(64) NOT NULL,
    observed_at timestamp with time zone NOT NULL,
    data_source character varying(20) NOT NULL,
    prcp double precision,
    humidity double precision,
    pressure double precision,
    cloud_cover double precision,
    tmin double precision,
    tmax double precision,
    tavg double precision,
    temp_range double precision,
    dew_point double precision,
    wspd double precision,
    pressure_delta_3h double precision,
    pressure_delta_6h double precision,
    humidity_delta_3h double precision,
    rain_rate_1h double precision,
    rain_accumulation_3h double precision,
    rain_accumulation_6h double precision,
    tdew_spread double precision,
    moisture_flux double precision,
    cloud_jump_3h double precision,
    prcp_climo_pct double precision,
    pressure_climo_z double precision,
    humidity_climo_pct double precision,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.feature_snapshots OWNER TO hydroguard;

--
-- Name: label_events; Type: TABLE; Schema: public; Owner: hydroguard
--

CREATE TABLE public.label_events (
    id character varying(36) NOT NULL,
    city_slug character varying(64) NOT NULL,
    observed_at timestamp with time zone NOT NULL,
    feature_snapshot_id character varying(36),
    weak_label smallint NOT NULL,
    weak_label_conf double precision NOT NULL,
    event_type character varying(32),
    source character varying(32) NOT NULL,
    source_weight double precision NOT NULL,
    raw_score double precision,
    rule_votes json,
    is_verified boolean DEFAULT false,
    verified_by character varying(64),
    verified_at timestamp with time zone,
    notes text,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.label_events OWNER TO hydroguard;

--
-- Name: model_registry; Type: TABLE; Schema: public; Owner: hydroguard
--

CREATE TABLE public.model_registry (
    id character varying(36) NOT NULL,
    city_slug character varying(64) NOT NULL,
    model_version character varying(64) NOT NULL,
    is_active boolean DEFAULT false NOT NULL,
    artifact_path text NOT NULL,
    ae_path text,
    tcn_path text,
    lgbm_path text,
    calibrator_path text,
    preprocessor_path text,
    training_run_id character varying(36),
    deployed_at timestamp with time zone,
    retired_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.model_registry OWNER TO hydroguard;

--
-- Name: prediction_events; Type: TABLE; Schema: public; Owner: hydroguard
--

CREATE TABLE public.prediction_events (
    inference_id character varying(36) NOT NULL,
    city_slug character varying(64) NOT NULL,
    model_version character varying(64) NOT NULL,
    calibration_version character varying(64) NOT NULL,
    weather_api_snapshot_id character varying(36),
    feature_snapshot_id character varying(36),
    ae_percentile double precision NOT NULL,
    tcn_percentile double precision NOT NULL,
    ae_variance double precision,
    tcn_variance double precision,
    model_entropy double precision,
    dynamics_snapshot json,
    p_event_raw double precision NOT NULL,
    p_event double precision NOT NULL,
    ci_lower double precision NOT NULL,
    ci_upper double precision NOT NULL,
    uncertainty double precision NOT NULL,
    risk_band character varying(20) NOT NULL,
    is_alert boolean NOT NULL,
    alert_threshold double precision NOT NULL,
    shap_values json,
    source character varying(20) NOT NULL,
    request_id character varying(64),
    inferred_at timestamp with time zone NOT NULL,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.prediction_events OWNER TO hydroguard;

--
-- Name: training_records; Type: TABLE; Schema: public; Owner: hydroguard
--

CREATE TABLE public.training_records (
    id integer NOT NULL,
    training_started timestamp without time zone NOT NULL,
    training_completed timestamp without time zone,
    training_duration_seconds double precision,
    total_samples integer,
    train_samples integer,
    validation_samples integer,
    num_cities integer,
    cities json,
    date_range_start timestamp without time zone,
    date_range_end timestamp without time zone,
    final_loss double precision,
    final_val_loss double precision,
    epochs_trained integer,
    threshold double precision,
    lstm_enabled boolean,
    lstm_final_loss double precision,
    lstm_epochs_trained integer,
    total_anomalies_detected integer,
    anomaly_percentage double precision,
    status character varying(50),
    error_message text,
    created_at timestamp with time zone
);


ALTER TABLE public.training_records OWNER TO hydroguard;

--
-- Name: training_records_id_seq; Type: SEQUENCE; Schema: public; Owner: hydroguard
--

CREATE SEQUENCE public.training_records_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.training_records_id_seq OWNER TO hydroguard;

--
-- Name: training_records_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: hydroguard
--

ALTER SEQUENCE public.training_records_id_seq OWNED BY public.training_records.id;


--
-- Name: training_runs; Type: TABLE; Schema: public; Owner: hydroguard
--

CREATE TABLE public.training_runs (
    id character varying(36) NOT NULL,
    city_slug character varying(64) NOT NULL,
    triggered_by character varying(32) NOT NULL,
    triggered_by_user character varying(64),
    status character varying(16) DEFAULT 'queued'::character varying NOT NULL,
    error_message text,
    dataset_hash character varying(64),
    data_rows integer,
    data_date_start date,
    data_date_end date,
    label_rows_used integer,
    positive_label_rate double precision,
    architecture json,
    hyperparameters json,
    git_commit character varying(40),
    model_version character varying(64),
    ae_train_loss double precision,
    ae_val_loss double precision,
    tcn_train_loss double precision,
    tcn_val_loss double precision,
    lgbm_val_auc double precision,
    lgbm_val_brier double precision,
    calibration_ece double precision,
    calibration_brier double precision,
    started_at timestamp with time zone,
    finished_at timestamp with time zone,
    duration_seconds double precision,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.training_runs OWNER TO hydroguard;

--
-- Name: users; Type: TABLE; Schema: public; Owner: hydroguard
--

CREATE TABLE public.users (
    id integer NOT NULL,
    email character varying(255) NOT NULL,
    username character varying(100) NOT NULL,
    hashed_pw character varying(255) NOT NULL,
    role character varying(20),
    is_active boolean,
    last_login timestamp with time zone,
    refresh_token_hash character varying(255),
    created_at timestamp with time zone
);


ALTER TABLE public.users OWNER TO hydroguard;

--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: hydroguard
--

CREATE SEQUENCE public.users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.users_id_seq OWNER TO hydroguard;

--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: hydroguard
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: weather_snapshots; Type: TABLE; Schema: public; Owner: hydroguard
--

CREATE TABLE public.weather_snapshots (
    id character varying(36) NOT NULL,
    city_slug character varying(64) NOT NULL,
    fetched_at timestamp with time zone NOT NULL,
    provider character varying(16) DEFAULT 'weatherapi'::character varying NOT NULL,
    api_response_hash character varying(64),
    temp_c double precision,
    feelslike_c double precision,
    humidity double precision,
    pressure_mb double precision,
    precip_mm double precision,
    cloud double precision,
    wind_kph double precision,
    dew_point_c double precision,
    vis_km double precision,
    uv_index double precision,
    condition_code integer,
    precip_mm_1h double precision,
    precip_mm_3h double precision,
    precip_mm_6h double precision,
    pressure_delta_3h double precision,
    pressure_delta_6h double precision,
    humidity_delta_3h double precision,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.weather_snapshots OWNER TO hydroguard;

--
-- Name: anomaly_records id; Type: DEFAULT; Schema: public; Owner: hydroguard
--

ALTER TABLE ONLY public.anomaly_records ALTER COLUMN id SET DEFAULT nextval('public.anomaly_records_id_seq'::regclass);


--
-- Name: training_records id; Type: DEFAULT; Schema: public; Owner: hydroguard
--

ALTER TABLE ONLY public.training_records ALTER COLUMN id SET DEFAULT nextval('public.training_records_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: hydroguard
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Data for Name: anomaly_records; Type: TABLE DATA; Schema: public; Owner: hydroguard
--

COPY public.anomaly_records (id, city, region, date, tmin, tmax, tavg, prcp, wspd, humidity, pressure, dew_point, cloud_cover, anomaly_score, threshold, is_anomaly, risk_level, hri_score, hri_label, cloudburst_risk_score, cloudburst_risk_category, is_cloudburst_likely, remarks, feature_contributions, detailed_explanation, created_at, updated_at, inference_id, model_version) FROM stdin;
\.


--
-- Data for Name: calibration_state; Type: TABLE DATA; Schema: public; Owner: hydroguard
--

COPY public.calibration_state (id, city_slug, model_version, calibrated_at, is_active, n_calibration_samples, brier_score_before, brier_score_after, ece_before, ece_after, artifact_path, created_at) FROM stdin;
\.


--
-- Data for Name: drift_state; Type: TABLE DATA; Schema: public; Owner: hydroguard
--

COPY public.drift_state (id, city_slug, checked_at, window_size, reference_rows, psi_scores, max_psi, drift_level, retrain_triggered, created_at) FROM stdin;
\.


--
-- Data for Name: feature_snapshots; Type: TABLE DATA; Schema: public; Owner: hydroguard
--

COPY public.feature_snapshots (id, city_slug, observed_at, data_source, prcp, humidity, pressure, cloud_cover, tmin, tmax, tavg, temp_range, dew_point, wspd, pressure_delta_3h, pressure_delta_6h, humidity_delta_3h, rain_rate_1h, rain_accumulation_3h, rain_accumulation_6h, tdew_spread, moisture_flux, cloud_jump_3h, prcp_climo_pct, pressure_climo_z, humidity_climo_pct, created_at) FROM stdin;
\.


--
-- Data for Name: label_events; Type: TABLE DATA; Schema: public; Owner: hydroguard
--

COPY public.label_events (id, city_slug, observed_at, feature_snapshot_id, weak_label, weak_label_conf, event_type, source, source_weight, raw_score, rule_votes, is_verified, verified_by, verified_at, notes, created_at) FROM stdin;
\.


--
-- Data for Name: model_registry; Type: TABLE DATA; Schema: public; Owner: hydroguard
--

COPY public.model_registry (id, city_slug, model_version, is_active, artifact_path, ae_path, tcn_path, lgbm_path, calibrator_path, preprocessor_path, training_run_id, deployed_at, retired_at, created_at) FROM stdin;
\.


--
-- Data for Name: prediction_events; Type: TABLE DATA; Schema: public; Owner: hydroguard
--

COPY public.prediction_events (inference_id, city_slug, model_version, calibration_version, weather_api_snapshot_id, feature_snapshot_id, ae_percentile, tcn_percentile, ae_variance, tcn_variance, model_entropy, dynamics_snapshot, p_event_raw, p_event, ci_lower, ci_upper, uncertainty, risk_band, is_alert, alert_threshold, shap_values, source, request_id, inferred_at, created_at) FROM stdin;
\.


--
-- Data for Name: training_records; Type: TABLE DATA; Schema: public; Owner: hydroguard
--

COPY public.training_records (id, training_started, training_completed, training_duration_seconds, total_samples, train_samples, validation_samples, num_cities, cities, date_range_start, date_range_end, final_loss, final_val_loss, epochs_trained, threshold, lstm_enabled, lstm_final_loss, lstm_epochs_trained, total_anomalies_detected, anomaly_percentage, status, error_message, created_at) FROM stdin;
\.


--
-- Data for Name: training_runs; Type: TABLE DATA; Schema: public; Owner: hydroguard
--

COPY public.training_runs (id, city_slug, triggered_by, triggered_by_user, status, error_message, dataset_hash, data_rows, data_date_start, data_date_end, label_rows_used, positive_label_rate, architecture, hyperparameters, git_commit, model_version, ae_train_loss, ae_val_loss, tcn_train_loss, tcn_val_loss, lgbm_val_auc, lgbm_val_brier, calibration_ece, calibration_brier, started_at, finished_at, duration_seconds, created_at) FROM stdin;
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: hydroguard
--

COPY public.users (id, email, username, hashed_pw, role, is_active, last_login, refresh_token_hash, created_at) FROM stdin;
1	zain@gmail.com	Zain	$2b$12$NZ5K.5QTfYSHB/2Y5CLQauZ7FhI7kAzM5pqVq8iWY0DL2yXtwfevS	USER	t	2026-05-07 21:26:20.139571+00	593a9936387ddc5b1308c1b4fa2a29735c4ae9a89539e7b9ed2b812fe0f43473	2026-05-05 21:50:05.756906+00
\.


--
-- Data for Name: weather_snapshots; Type: TABLE DATA; Schema: public; Owner: hydroguard
--

COPY public.weather_snapshots (id, city_slug, fetched_at, provider, api_response_hash, temp_c, feelslike_c, humidity, pressure_mb, precip_mm, cloud, wind_kph, dew_point_c, vis_km, uv_index, condition_code, precip_mm_1h, precip_mm_3h, precip_mm_6h, pressure_delta_3h, pressure_delta_6h, humidity_delta_3h, created_at) FROM stdin;
\.


--
-- Name: anomaly_records_id_seq; Type: SEQUENCE SET; Schema: public; Owner: hydroguard
--

SELECT pg_catalog.setval('public.anomaly_records_id_seq', 1, false);


--
-- Name: training_records_id_seq; Type: SEQUENCE SET; Schema: public; Owner: hydroguard
--

SELECT pg_catalog.setval('public.training_records_id_seq', 1, false);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: hydroguard
--

SELECT pg_catalog.setval('public.users_id_seq', 1, true);


--
-- Name: anomaly_records anomaly_records_pkey; Type: CONSTRAINT; Schema: public; Owner: hydroguard
--

ALTER TABLE ONLY public.anomaly_records
    ADD CONSTRAINT anomaly_records_pkey PRIMARY KEY (id);


--
-- Name: calibration_state calibration_state_pkey; Type: CONSTRAINT; Schema: public; Owner: hydroguard
--

ALTER TABLE ONLY public.calibration_state
    ADD CONSTRAINT calibration_state_pkey PRIMARY KEY (id);


--
-- Name: drift_state drift_state_pkey; Type: CONSTRAINT; Schema: public; Owner: hydroguard
--

ALTER TABLE ONLY public.drift_state
    ADD CONSTRAINT drift_state_pkey PRIMARY KEY (id);


--
-- Name: feature_snapshots feature_snapshots_pkey; Type: CONSTRAINT; Schema: public; Owner: hydroguard
--

ALTER TABLE ONLY public.feature_snapshots
    ADD CONSTRAINT feature_snapshots_pkey PRIMARY KEY (id);


--
-- Name: label_events label_events_pkey; Type: CONSTRAINT; Schema: public; Owner: hydroguard
--

ALTER TABLE ONLY public.label_events
    ADD CONSTRAINT label_events_pkey PRIMARY KEY (id);


--
-- Name: model_registry model_registry_model_version_key; Type: CONSTRAINT; Schema: public; Owner: hydroguard
--

ALTER TABLE ONLY public.model_registry
    ADD CONSTRAINT model_registry_model_version_key UNIQUE (model_version);


--
-- Name: model_registry model_registry_pkey; Type: CONSTRAINT; Schema: public; Owner: hydroguard
--

ALTER TABLE ONLY public.model_registry
    ADD CONSTRAINT model_registry_pkey PRIMARY KEY (id);


--
-- Name: prediction_events prediction_events_pkey; Type: CONSTRAINT; Schema: public; Owner: hydroguard
--

ALTER TABLE ONLY public.prediction_events
    ADD CONSTRAINT prediction_events_pkey PRIMARY KEY (inference_id);


--
-- Name: training_records training_records_pkey; Type: CONSTRAINT; Schema: public; Owner: hydroguard
--

ALTER TABLE ONLY public.training_records
    ADD CONSTRAINT training_records_pkey PRIMARY KEY (id);


--
-- Name: training_runs training_runs_pkey; Type: CONSTRAINT; Schema: public; Owner: hydroguard
--

ALTER TABLE ONLY public.training_runs
    ADD CONSTRAINT training_runs_pkey PRIMARY KEY (id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: hydroguard
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: weather_snapshots weather_snapshots_pkey; Type: CONSTRAINT; Schema: public; Owner: hydroguard
--

ALTER TABLE ONLY public.weather_snapshots
    ADD CONSTRAINT weather_snapshots_pkey PRIMARY KEY (id);


--
-- Name: ix_anomaly_records_city; Type: INDEX; Schema: public; Owner: hydroguard
--

CREATE INDEX ix_anomaly_records_city ON public.anomaly_records USING btree (city);


--
-- Name: ix_anomaly_records_date; Type: INDEX; Schema: public; Owner: hydroguard
--

CREATE INDEX ix_anomaly_records_date ON public.anomaly_records USING btree (date);


--
-- Name: ix_anomaly_records_id; Type: INDEX; Schema: public; Owner: hydroguard
--

CREATE INDEX ix_anomaly_records_id ON public.anomaly_records USING btree (id);


--
-- Name: ix_anomaly_records_region; Type: INDEX; Schema: public; Owner: hydroguard
--

CREATE INDEX ix_anomaly_records_region ON public.anomaly_records USING btree (region);


--
-- Name: ix_anomaly_records_risk_level; Type: INDEX; Schema: public; Owner: hydroguard
--

CREATE INDEX ix_anomaly_records_risk_level ON public.anomaly_records USING btree (risk_level);


--
-- Name: ix_calibration_state_city_slug; Type: INDEX; Schema: public; Owner: hydroguard
--

CREATE INDEX ix_calibration_state_city_slug ON public.calibration_state USING btree (city_slug);


--
-- Name: ix_calibration_state_is_active; Type: INDEX; Schema: public; Owner: hydroguard
--

CREATE INDEX ix_calibration_state_is_active ON public.calibration_state USING btree (is_active);


--
-- Name: ix_drift_state_city_slug; Type: INDEX; Schema: public; Owner: hydroguard
--

CREATE INDEX ix_drift_state_city_slug ON public.drift_state USING btree (city_slug);


--
-- Name: ix_drift_state_max_psi; Type: INDEX; Schema: public; Owner: hydroguard
--

CREATE INDEX ix_drift_state_max_psi ON public.drift_state USING btree (max_psi);


--
-- Name: ix_feature_snapshots_city_slug; Type: INDEX; Schema: public; Owner: hydroguard
--

CREATE INDEX ix_feature_snapshots_city_slug ON public.feature_snapshots USING btree (city_slug);


--
-- Name: ix_feature_snapshots_observed_at; Type: INDEX; Schema: public; Owner: hydroguard
--

CREATE INDEX ix_feature_snapshots_observed_at ON public.feature_snapshots USING btree (observed_at);


--
-- Name: ix_label_events_city_slug; Type: INDEX; Schema: public; Owner: hydroguard
--

CREATE INDEX ix_label_events_city_slug ON public.label_events USING btree (city_slug);


--
-- Name: ix_label_events_observed_at; Type: INDEX; Schema: public; Owner: hydroguard
--

CREATE INDEX ix_label_events_observed_at ON public.label_events USING btree (observed_at);


--
-- Name: ix_model_registry_city_slug; Type: INDEX; Schema: public; Owner: hydroguard
--

CREATE INDEX ix_model_registry_city_slug ON public.model_registry USING btree (city_slug);


--
-- Name: ix_model_registry_is_active; Type: INDEX; Schema: public; Owner: hydroguard
--

CREATE INDEX ix_model_registry_is_active ON public.model_registry USING btree (is_active);


--
-- Name: ix_prediction_events_city_slug; Type: INDEX; Schema: public; Owner: hydroguard
--

CREATE INDEX ix_prediction_events_city_slug ON public.prediction_events USING btree (city_slug);


--
-- Name: ix_prediction_events_is_alert; Type: INDEX; Schema: public; Owner: hydroguard
--

CREATE INDEX ix_prediction_events_is_alert ON public.prediction_events USING btree (is_alert);


--
-- Name: ix_prediction_events_p_event; Type: INDEX; Schema: public; Owner: hydroguard
--

CREATE INDEX ix_prediction_events_p_event ON public.prediction_events USING btree (p_event);


--
-- Name: ix_prediction_events_risk_band; Type: INDEX; Schema: public; Owner: hydroguard
--

CREATE INDEX ix_prediction_events_risk_band ON public.prediction_events USING btree (risk_band);


--
-- Name: ix_training_records_id; Type: INDEX; Schema: public; Owner: hydroguard
--

CREATE INDEX ix_training_records_id ON public.training_records USING btree (id);


--
-- Name: ix_training_runs_city_slug; Type: INDEX; Schema: public; Owner: hydroguard
--

CREATE INDEX ix_training_runs_city_slug ON public.training_runs USING btree (city_slug);


--
-- Name: ix_users_email; Type: INDEX; Schema: public; Owner: hydroguard
--

CREATE UNIQUE INDEX ix_users_email ON public.users USING btree (email);


--
-- Name: ix_users_id; Type: INDEX; Schema: public; Owner: hydroguard
--

CREATE INDEX ix_users_id ON public.users USING btree (id);


--
-- Name: ix_users_username; Type: INDEX; Schema: public; Owner: hydroguard
--

CREATE UNIQUE INDEX ix_users_username ON public.users USING btree (username);


--
-- Name: ix_weather_snapshots_city_slug; Type: INDEX; Schema: public; Owner: hydroguard
--

CREATE INDEX ix_weather_snapshots_city_slug ON public.weather_snapshots USING btree (city_slug);


--
-- Name: ix_weather_snapshots_fetched_at; Type: INDEX; Schema: public; Owner: hydroguard
--

CREATE INDEX ix_weather_snapshots_fetched_at ON public.weather_snapshots USING btree (fetched_at);


--
-- PostgreSQL database dump complete
--

\unrestrict TeadJImy097ytkW6YA6YOYwPulON9SFxxBbD9UqjTyJU5CfNshxdAyDpcgbISCq

