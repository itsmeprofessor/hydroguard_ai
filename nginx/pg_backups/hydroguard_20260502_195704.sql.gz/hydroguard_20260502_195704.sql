--
-- PostgreSQL database dump
--

\restrict 0F8eUHW7XNQwbgSkpZyvX5B8gD3iXXNFzJJRIygFIV03a4fQcwk4UEhXViLSscK

-- Dumped from database version 16.13
-- Dumped by pg_dump version 16.13

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: anomaly_records; Type: TABLE; Schema: public; Owner: hydroguard
--

CREATE TABLE public.anomaly_records (
    id integer NOT NULL,
    city character varying(100),
    region character varying(100),
    date timestamp without time zone,
    tmin double precision,
    tmax double precision,
    tavg double precision,
    prcp double precision,
    wspd double precision,
    humidity double precision,
    pressure double precision,
    dew_point double precision,
    cloud_cover double precision,
    anomaly_score double precision NOT NULL,
    threshold double precision NOT NULL,
    is_anomaly boolean NOT NULL,
    risk_level character varying(20),
    hri_score integer,
    hri_label character varying(20),
    cloudburst_risk_score double precision,
    cloudburst_risk_category character varying(20),
    is_cloudburst_likely boolean,
    remarks text,
    feature_contributions json,
    detailed_explanation json,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.anomaly_records OWNER TO hydroguard;

--
-- Name: anomaly_records_id_seq; Type: SEQUENCE; Schema: public; Owner: hydroguard
--

CREATE SEQUENCE public.anomaly_records_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.anomaly_records_id_seq OWNER TO hydroguard;

--
-- Name: anomaly_records_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: hydroguard
--

ALTER SEQUENCE public.anomaly_records_id_seq OWNED BY public.anomaly_records.id;


--
-- Name: training_records; Type: TABLE; Schema: public; Owner: hydroguard
--

CREATE TABLE public.training_records (
    id integer NOT NULL,
    training_started timestamp without time zone NOT NULL,
    training_completed timestamp without time zone,
    training_duration_seconds double precision,
    total_samples integer,
    train_samples integer,
    validation_samples integer,
    num_cities integer,
    cities json,
    date_range_start timestamp without time zone,
    date_range_end timestamp without time zone,
    final_loss double precision,
    final_val_loss double precision,
    epochs_trained integer,
    threshold double precision,
    lstm_enabled boolean,
    lstm_final_loss double precision,
    lstm_epochs_trained integer,
    total_anomalies_detected integer,
    anomaly_percentage double precision,
    status character varying(50),
    error_message text,
    created_at timestamp without time zone
);


ALTER TABLE public.training_records OWNER TO hydroguard;

--
-- Name: training_records_id_seq; Type: SEQUENCE; Schema: public; Owner: hydroguard
--

CREATE SEQUENCE public.training_records_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.training_records_id_seq OWNER TO hydroguard;

--
-- Name: training_records_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: hydroguard
--

ALTER SEQUENCE public.training_records_id_seq OWNED BY public.training_records.id;


--
-- Name: users; Type: TABLE; Schema: public; Owner: hydroguard
--

CREATE TABLE public.users (
    id integer NOT NULL,
    email character varying(255) NOT NULL,
    username character varying(100) NOT NULL,
    hashed_pw character varying(255) NOT NULL,
    role character varying(20),
    is_active boolean,
    last_login timestamp without time zone,
    refresh_token_hash character varying(255),
    created_at timestamp without time zone
);


ALTER TABLE public.users OWNER TO hydroguard;

--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: hydroguard
--

CREATE SEQUENCE public.users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.users_id_seq OWNER TO hydroguard;

--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: hydroguard
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: anomaly_records id; Type: DEFAULT; Schema: public; Owner: hydroguard
--

ALTER TABLE ONLY public.anomaly_records ALTER COLUMN id SET DEFAULT nextval('public.anomaly_records_id_seq'::regclass);


--
-- Name: training_records id; Type: DEFAULT; Schema: public; Owner: hydroguard
--

ALTER TABLE ONLY public.training_records ALTER COLUMN id SET DEFAULT nextval('public.training_records_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: hydroguard
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Data for Name: anomaly_records; Type: TABLE DATA; Schema: public; Owner: hydroguard
--

COPY public.anomaly_records (id, city, region, date, tmin, tmax, tavg, prcp, wspd, humidity, pressure, dew_point, cloud_cover, anomaly_score, threshold, is_anomaly, risk_level, hri_score, hri_label, cloudburst_risk_score, cloudburst_risk_category, is_cloudburst_likely, remarks, feature_contributions, detailed_explanation, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: training_records; Type: TABLE DATA; Schema: public; Owner: hydroguard
--

COPY public.training_records (id, training_started, training_completed, training_duration_seconds, total_samples, train_samples, validation_samples, num_cities, cities, date_range_start, date_range_end, final_loss, final_val_loss, epochs_trained, threshold, lstm_enabled, lstm_final_loss, lstm_epochs_trained, total_anomalies_detected, anomaly_percentage, status, error_message, created_at) FROM stdin;
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: hydroguard
--

COPY public.users (id, email, username, hashed_pw, role, is_active, last_login, refresh_token_hash, created_at) FROM stdin;
\.


--
-- Name: anomaly_records_id_seq; Type: SEQUENCE SET; Schema: public; Owner: hydroguard
--

SELECT pg_catalog.setval('public.anomaly_records_id_seq', 1, false);


--
-- Name: training_records_id_seq; Type: SEQUENCE SET; Schema: public; Owner: hydroguard
--

SELECT pg_catalog.setval('public.training_records_id_seq', 1, false);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: hydroguard
--

SELECT pg_catalog.setval('public.users_id_seq', 1, false);


--
-- Name: anomaly_records anomaly_records_pkey; Type: CONSTRAINT; Schema: public; Owner: hydroguard
--

ALTER TABLE ONLY public.anomaly_records
    ADD CONSTRAINT anomaly_records_pkey PRIMARY KEY (id);


--
-- Name: training_records training_records_pkey; Type: CONSTRAINT; Schema: public; Owner: hydroguard
--

ALTER TABLE ONLY public.training_records
    ADD CONSTRAINT training_records_pkey PRIMARY KEY (id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: hydroguard
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: ix_anomaly_records_city; Type: INDEX; Schema: public; Owner: hydroguard
--

CREATE INDEX ix_anomaly_records_city ON public.anomaly_records USING btree (city);


--
-- Name: ix_anomaly_records_date; Type: INDEX; Schema: public; Owner: hydroguard
--

CREATE INDEX ix_anomaly_records_date ON public.anomaly_records USING btree (date);


--
-- Name: ix_anomaly_records_id; Type: INDEX; Schema: public; Owner: hydroguard
--

CREATE INDEX ix_anomaly_records_id ON public.anomaly_records USING btree (id);


--
-- Name: ix_anomaly_records_region; Type: INDEX; Schema: public; Owner: hydroguard
--

CREATE INDEX ix_anomaly_records_region ON public.anomaly_records USING btree (region);


--
-- Name: ix_anomaly_records_risk_level; Type: INDEX; Schema: public; Owner: hydroguard
--

CREATE INDEX ix_anomaly_records_risk_level ON public.anomaly_records USING btree (risk_level);


--
-- Name: ix_training_records_id; Type: INDEX; Schema: public; Owner: hydroguard
--

CREATE INDEX ix_training_records_id ON public.training_records USING btree (id);


--
-- Name: ix_users_email; Type: INDEX; Schema: public; Owner: hydroguard
--

CREATE UNIQUE INDEX ix_users_email ON public.users USING btree (email);


--
-- Name: ix_users_id; Type: INDEX; Schema: public; Owner: hydroguard
--

CREATE INDEX ix_users_id ON public.users USING btree (id);


--
-- Name: ix_users_username; Type: INDEX; Schema: public; Owner: hydroguard
--

CREATE UNIQUE INDEX ix_users_username ON public.users USING btree (username);


--
-- PostgreSQL database dump complete
--

\unrestrict 0F8eUHW7XNQwbgSkpZyvX5B8gD3iXXNFzJJRIygFIV03a4fQcwk4UEhXViLSscK

